﻿import { FileBlob, SpreadsheetFile } from '@oai/artifact-tool';
const input = await FileBlob.load('C:/Users/nov/Desktop/申请进度大表（沟通小结自动生成）.xlsx');
const wb = await SpreadsheetFile.importXlsx(input);
console.log((await wb.inspect({kind:'sheet', include:'id,name', maxChars:4000})).ndjson);
console.log('--- summary ---');
console.log((await wb.inspect({kind:'workbook,sheet,table', tableMaxRows:8, tableMaxCols:12, maxChars:12000})).ndjson);
console.log('--- formulas ---');
console.log((await wb.inspect({kind:'formula', maxChars:12000, options:{maxResults:120}})).ndjson);
