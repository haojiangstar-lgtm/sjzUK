const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];

const state = {
  route: "overview",
  docs: [],
  clients: [],
  clientFilter: "active",
  summary: {
    tab: "applications",
    query: "",
    status: "all",
    rows: [],
    followups: []
  },
  usageRange: "7天",
  settingsTab: "usage",
  editorText: "",
  pendingClientFile: null,
  humanize: {
    model: "v7.0.2",
    genre: "个人陈述 (Personal Statement)",
    level: "高级 (Advanced)",
    boosted: false
  }
};

const routes = {
  "/overview": "overview",
  "/student-summary": "studentSummary",
  "/client": "client",
  "/docs": "docs",
  "/agentic": "agentic",
  "/writer/ps": "ps",
  "/writer/pe": "pe",
  "/writer/rl": "rl",
  "/writer/cv": "cv",
  "/writer/fw": "fw",
  "/tool/humanize": "humanize",
  "/settings": "settings",
  "/affiliate": "affiliate"
};

const labels = {
  overview: "总览",
  studentSummary: "学生汇总",
  client: "客户",
  docs: "我的作品",
  agentic: "Agentic",
  ps: "写PS",
  pe: "写命题文书",
  rl: "写推荐信",
  cv: "写CV",
  fw: "自由创作",
  humanize: "Tool › Humanize",
  settings: "设置",
  affiliate: "推广合作"
};

const samples = {
  ps: "I want to explore media studies because I have seen how stories can help people understand one another across cultures. My experience directing a student film taught me to listen carefully, revise patiently, and turn personal observations into work that can move an audience.",
  pe: "This essay responds to the prompt by connecting the applicant's academic interests with concrete experiences, community impact, and future goals.",
  rl: "I am pleased to recommend this student for your program. She consistently demonstrates curiosity, discipline, and a rare ability to translate feedback into stronger work.",
  cv: "EDUCATION\nGuangzhou International School\n\nEXPERIENCE\nStudent Film Director - Led scriptwriting, filming, editing, and festival submission.",
  fw: "The first time I edited a film alone, I realized that storytelling is less about decoration and more about choosing what deserves attention."
};

const applicationColumns = [
  "序号", "备注", "CV", "RL", "PS", "中文姓名", "前期", "中期", "合同类型", "入学日期", "性别", "申请邮箱时所用电话", "雅思成绩", "院校名称", "专业", "平均分", "申请学校", "申请专业", "申请链接", "申请开放日期", "申请截止日期", "申请日期", "回执日期", "是否补件", "补件截止日期", "申请结果", "Offer状态", "语言要求", "成绩要求", "满足条件最晚时间", "学费 (英镑)", "押金（英镑）", "押金支付截止", "剩余天数", "开学时间", "最晚回复日期", "接录取日期"
];

const followupColumns = [
  "姓名", "前期", "中期", "是否定校", "后续工作告知单", "存单", "护照", "肺结核", "正课住宿", "正课学费", "正课住宿费", "语言课", "语言课住宿", "语言课住宿费", "语言课学费", "CAS", "最终学术材料", "签证", "邮箱", "是否需要ATAS", "注册"
];

function makeRow(columns, values = {}) {
  return Object.fromEntries(columns.map((column) => [column, values[column] ?? ""]));
}

function excelDateToDate(value) {
  if (!value) return null;
  if (value instanceof Date) return value;
  if (typeof value === "number") return new Date(Math.round((value - 25569) * 86400 * 1000));
  const parsed = new Date(value);
  return Number.isNaN(parsed.getTime()) ? null : parsed;
}

function dateToDisplay(value) {
  const date = excelDateToDate(value);
  if (!date) return value || "";
  return date.toISOString().slice(0, 10);
}

function computeRemainingDays(row) {
  const result = String(row["申请结果"] || "");
  const deadlineValue = row["押金支付截止"];
  const status = String(deadlineValue || "");
  const deadline = excelDateToDate(deadlineValue);
  if (result === "放弃" || !deadlineValue || status.includes("缴纳") || !deadline) return "无";
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  deadline.setHours(0, 0, 0, 0);
  return Math.ceil((deadline - today) / 86400000);
}

function defaultSummaryRows() {
  return [
    makeRow(applicationColumns, { "序号": 1, "CV": "✅", "PS": "进行中", "中文姓名": "刘洋珂", "前期": "吴启明", "中期": "张正青", "合同类型": "全程", "入学日期": "2026-09", "雅思成绩": "IELTS 7.0", "院校名称": "Sheffield", "专业": "Media", "平均分": "85", "申请学校": "University of Sheffield", "申请专业": "MA Digital Media", "申请日期": "2026-01-12", "申请结果": "Offer", "Offer状态": "待缴押金", "语言要求": "7.0", "成绩要求": "均分85", "学费 (英镑)": 26000, "押金（英镑）": 2000, "押金支付截止": "2026-06-15", "开学时间": "2026-09-20" }),
    makeRow(applicationColumns, { "序号": 2, "中文姓名": "冯若琳", "前期": "葛晓娜", "中期": "李雅楠", "院校名称": "Glasgow", "专业": "TESOL", "申请学校": "University of Glasgow", "申请结果": "审理中", "Offer状态": "等待结果", "押金支付截止": "", "开学时间": "2026-09-15" }),
    makeRow(applicationColumns, { "序号": 3, "CV": "✅", "RL": "✅", "PS": "✅", "中文姓名": "王欣悦", "前期": "徐雅雯", "中期": "李雅楠", "院校名称": "Edinburgh", "专业": "Education", "申请学校": "University of Edinburgh", "申请结果": "Offer", "Offer状态": "押金已缴纳", "押金支付截止": "已缴纳", "开学时间": "2026-09-10" })
  ].map(recalculateApplicationRow);
}

function defaultFollowupRows() {
  return [
    makeRow(followupColumns, { "姓名": "刘洋珂", "前期": "吴启明", "中期": "张正青", "是否定校": "Sheffield", "后续工作告知单": "✅", "肺结核": "已通知", "正课住宿": "hino" }),
    makeRow(followupColumns, { "姓名": "冯若琳", "前期": "葛晓娜", "中期": "李雅楠", "是否定校": "Kaplan-Glasgow", "后续工作告知单": "✅", "存单": "✅", "肺结核": "已通知" }),
    makeRow(followupColumns, { "姓名": "王欣悦", "前期": "徐雅雯", "中期": "李雅楠", "是否定校": "Edinburgh", "后续工作告知单": "✅", "存单": "✅", "护照": "✅", "语言课": "6周线下7.20-8.28", "语言课学费": "已缴纳" })
  ];
}

function recalculateApplicationRow(row) {
  row["剩余天数"] = computeRemainingDays(row);
  return row;
}

state.summary.rows = defaultSummaryRows();
state.summary.followups = defaultFollowupRows();

function showToast(text) {
  const toast = $("#toast");
  toast.textContent = text;
  toast.classList.add("show");
  setTimeout(() => toast.classList.remove("show"), 1700);
}

function icon(name) {
  return `<i data-lucide="${name}"></i>`;
}

function setRoute(route) {
  state.route = route;
  const hash = Object.entries(routes).find(([, value]) => value === route)?.[0] || "/overview";
  if (location.hash !== `#${hash}`) location.hash = hash;
  render();
}

function routeFromHash() {
  const hash = location.hash.replace("#", "") || "/overview";
  return routes[hash] || "overview";
}

function shell(title, subtitle, actions = "") {
  return `
    <section class="page-title">
      <div>
        <h1>${title}</h1>
        <p>${subtitle}</p>
      </div>
      <div class="page-actions">${actions}</div>
    </section>
  `;
}

function statCards() {
  return `
    <section class="dash-stats">
      <article><span>活跃客户</span><strong>${state.clients.length}</strong><small>0% vs 上月</small></article>
      <article><span>创作文档</span><strong>${state.docs.length}</strong><small>0% vs 上月</small></article>
      <article><span>已为你节省</span><strong>${state.docs.length * 2}</strong><small>小时 · 共帮你创作 ${state.docs.length * 680} 词</small></article>
      <article><span>剩余额度</span><strong>1,000</strong><small>词 <button class="mini-link" data-action="settings">充值</button> <button class="mini-link" data-action="usage">使用记录</button></small></article>
    </section>
  `;
}

function overviewView() {
  const quick = [
    ["agentic", "文书Agent", "AI智能代理，自动完成全套留学文书撰写", "wand-sparkles"],
    ["client", "智能建档", "上传学生信息表仅数十秒快速识别建档", "folder-search"],
    ["ps", "撰写PS", "可自由控制大纲的PS生成大模型", "file-pen-line"],
    ["pe", "命题Essay", "提供命题，一键生成Essay", "list-checks"],
    ["rl", "推荐信", "仅提供推荐人信息和亮点", "mail-check"],
    ["cv", "生成CV", "无需手动输入即可生成专业格式简历", "badge-check"],
    ["humanize", "降AI率", "自主研发拟人化转写大模型", "eraser"],
    ["fw", "智能编辑器", "AI增强编辑器，快速创作文案", "pen-tool"]
  ];
  return `
    ${shell("嗨 郝江，下午好", "欢迎回到 EduPro AI，我们一起继续高效工作吧", `
      <button class="quick-card horizontal" data-action="video">${icon("play-circle")}<span><b>视频演示</b><small>了解 EduPro 核心功能</small></span></button>
      <button class="quick-card horizontal" data-action="guide">${icon("rocket")}<span><b>快速开始</b><small>完整上手指南</small></span></button>
    `)}
    <div class="account-pills"><span>${icon("badge-check")} oydbx2ag10k22x9rmwihzgdvvobi@wx.local</span><span>${icon("shield-check")} 主账号</span></div>
    <h2 class="section-title">数据概览</h2>
    ${statCards()}
    <h2 class="section-title">快速操作</h2>
    <section class="quick-grid">
      ${quick.map(([route, title, desc, iconName]) => `<button class="quick-card" data-route="${route}">${icon(iconName)}<h3>${title}</h3><p>${desc}</p></button>`).join("")}
    </section>
    <section class="dash-grid two-col">
      <article class="dash-card"><h3>更新日志</h3>${updates()}</article>
      <article class="dash-card"><h3>近期客户</h3><p class="muted">快速访问学生档案 · ${state.clients.length} 位客户</p>${clientList(true)}<h3>最近动态</h3><p class="muted">${state.docs.length ? "刚刚生成了新的文书" : "暂无活动记录"}</p></article>
    </section>
  `;
}

function updates() {
  const items = [
    ["2026-01-29", "移动端体验大升级", "全部写作工具的交互体验已针对移动端优化。"],
    ["2026-01-27", "智能建档引擎2.0上线", "信息提取能力升级，支持更多非固定项信息。"],
    ["2026-01-25", "功能升级更新", "文书 Agent、降 AI 率 Agent 与 PS 写作算法优化。"],
    ["2025-11-20", "降AI率模型 V7.0.2", "加强模式上线，适合难降下来的文案。"]
  ];
  return `<div class="timeline">${items.map(([date, title, text]) => `<div><time>${date}</time><b>${title}</b><p>${text}</p></div>`).join("")}</div>`;
}

function clientList(compact = false) {
  const visibleClients = state.clients.filter((client) => state.clientFilter === "archived" ? client.status === "已归档" : client.status !== "已归档");
  if (!visibleClients.length) {
    const isArchived = state.clientFilter === "archived";
    return `<div class="empty-box"><h3>${isArchived ? "暂无已归档学生" : "暂无学生档案"}</h3><p>${isArchived ? "点击服务中学生的归档按钮后，会移动到这里。" : "创建您的第一个学生档案开始使用"}</p>${isArchived ? "" : `<button class="primary-btn small" data-action="createClient">${compact ? "创建学生档案" : "创建客户"}</button>`}</div>`;
  }
  return `<div class="client-profile-grid">${visibleClients.map(clientCard).join("")}</div>`;
}

function clientCard(c) {
  const profile = c.profile || buildParsedProfile(c.name);
  const isArchived = c.status === "已归档";
  return `
    <article class="student-profile-card">
      <div class="student-profile-head">
        <div>
          <span class="tag">${c.status}</span>
          <h3>${c.name}</h3>
          <p>${profile.target.degree} · ${profile.target.major} · ${profile.target.region}</p>
        </div>
        <button class="mini-link" data-action="${isArchived ? "restoreClient" : "archiveClient"}" data-name="${c.name}">${isArchived ? "恢复服务中" : "归档"}</button>
      </div>
      <div class="profile-sections">
        <section>
          <h4>基础信息</h4>
          <dl>
            <div><dt>英文名</dt><dd>${profile.basic.englishName}</dd></div>
            <div><dt>当前学校</dt><dd>${profile.basic.school}</dd></div>
            <div><dt>GPA</dt><dd>${profile.basic.gpa}</dd></div>
            <div><dt>语言</dt><dd>${profile.basic.language}</dd></div>
          </dl>
        </section>
        <section>
          <h4>申请目标</h4>
          <dl>
            <div><dt>目标地区</dt><dd>${profile.target.region}</dd></div>
            <div><dt>申请阶段</dt><dd>${profile.target.degree}</dd></div>
            <div><dt>目标专业</dt><dd>${profile.target.major}</dd></div>
            <div><dt>偏好院校</dt><dd>${profile.target.schools.join(" / ")}</dd></div>
          </dl>
        </section>
        <section>
          <h4>经历亮点</h4>
          <ul>${profile.highlights.map(item => `<li>${item}</li>`).join("")}</ul>
        </section>
        <section>
          <h4>材料清单</h4>
          <ul>${profile.materials.map(item => `<li>${item}</li>`).join("")}</ul>
        </section>
      </div>
    </article>
  `;
}

function clientView() {
  return `
    ${shell("学生档案", "管理您的所有客户信息", `<button class="primary-btn small" data-action="createClient">${icon("plus")}创建客户</button>`)}
    <div class="tabs"><button class="${state.clientFilter === "active" ? "active" : ""}" data-action="setClientFilter" data-filter="active">服务中</button><button class="${state.clientFilter === "archived" ? "active" : ""}" data-action="setClientFilter" data-filter="archived">已归档</button><button class="icon-btn" data-action="toggleList">${icon("list")}</button><button class="icon-btn" data-action="toggleGrid">${icon("grid-2x2")}</button></div>
    <section class="dash-card">${clientList()}</section>
  `;
}

function studentSummaryView() {
  const rows = getFilteredSummaryRows();
  const totalStudents = new Set(state.summary.rows.map((row) => row["中文姓名"]).filter(Boolean)).size;
  const offerCount = state.summary.rows.filter((row) => String(row["申请结果"] || "").includes("Offer")).length;
  const urgentCount = state.summary.rows.filter((row) => typeof row["剩余天数"] === "number" && row["剩余天数"] <= 14).length;
  const completedDocs = state.summary.rows.filter((row) => ["CV", "RL", "PS"].every((col) => String(row[col] || "").includes("✅"))).length;
  return `
    ${shell("学生汇总", "复刻申请进度大表：支持公式计算、上传整理、在线编辑和下载 Excel", `
      <input id="summaryUpload" type="file" accept=".xlsx,.xls,.csv" hidden />
      <button class="secondary-btn small" data-action="uploadSummary">${icon("upload")}上传文件</button>
      <button class="primary-btn small" data-action="downloadSummary">${icon("download")}下载文件</button>
    `)}
    <section class="summary-kpis">
      <article><span>学生数</span><strong>${totalStudents}</strong></article>
      <article><span>申请记录</span><strong>${state.summary.rows.length}</strong></article>
      <article><span>Offer</span><strong>${offerCount}</strong></article>
      <article><span>押金临期</span><strong>${urgentCount}</strong></article>
      <article><span>文书齐套</span><strong>${completedDocs}</strong></article>
    </section>
    <section class="dash-card summary-panel">
      <div class="summary-toolbar">
        <div class="tabs">
          <button class="${state.summary.tab === "applications" ? "active" : ""}" data-action="setSummaryTab" data-tab="applications">2026入学学生申请</button>
          <button class="${state.summary.tab === "followups" ? "active" : ""}" data-action="setSummaryTab" data-tab="followups">学生后续安排</button>
        </div>
        <div class="summary-tools">
          <input id="summarySearch" placeholder="搜索学生/学校/顾问" value="${state.summary.query}" />
          <select id="summaryStatus">
            ${["all", "Offer", "审理中", "放弃", "押金临期"].map((value) => `<option value="${value}" ${state.summary.status === value ? "selected" : ""}>${value === "all" ? "全部状态" : value}</option>`).join("")}
          </select>
          <button class="secondary-btn small" data-action="addSummaryRow">${icon("plus")}新增行</button>
          <button class="secondary-btn small" data-action="recalculateSummary">${icon("calculator")}公式重算</button>
        </div>
      </div>
      <div class="formula-note">${icon("function-square")} 剩余天数公式：若申请结果为“放弃”、押金截止为空、已缴纳或不是日期，则显示“无”；否则计算“押金支付截止 - 今天”。</div>
      ${state.summary.tab === "applications" ? summaryTable(applicationColumns, rows, "applications") : summaryTable(followupColumns, state.summary.followups, "followups")}
    </section>
  `;
}

function getFilteredSummaryRows() {
  const query = state.summary.query.trim().toLowerCase();
  return state.summary.rows.filter((row) => {
    const text = Object.values(row).join(" ").toLowerCase();
    const statusOk =
      state.summary.status === "all" ||
      (state.summary.status === "押金临期" ? typeof row["剩余天数"] === "number" && row["剩余天数"] <= 14 : text.includes(state.summary.status.toLowerCase()));
    return statusOk && (!query || text.includes(query));
  });
}

function summaryTable(columns, rows, tableName) {
  return `
    <div class="summary-table-wrap">
      <table class="summary-table" data-table="${tableName}">
        <thead><tr>${columns.map((column) => `<th>${column}</th>`).join("")}</tr></thead>
        <tbody>
          ${rows.map((row, rowIndex) => `<tr>${columns.map((column) => {
            const readonly = column === "剩余天数";
            const raw = row[column] ?? "";
            const value = column.includes("日期") || column.includes("时间") || column.includes("截止") ? dateToDisplay(raw) : raw;
            return `<td class="${readonly ? "formula-cell" : ""}"><input ${readonly ? "readonly" : ""} data-summary-table="${tableName}" data-row="${rowIndex}" data-col="${column}" value="${String(value).replaceAll('"', "&quot;")}" /></td>`;
          }).join("")}</tr>`).join("")}
        </tbody>
      </table>
    </div>
  `;
}

function docsView() {
  const docs = state.docs.length ? state.docs : [];
  return `
    ${shell("我的作品", "查看、搜索和管理已生成的文档", `<button class="secondary-btn small" data-route="fw">${icon("plus")}新建文档</button>`)}
    <section class="dash-card">
      ${docs.length ? `<div class="task-table">${docs.map(doc => `<div><span>${doc.title}</span><b>${doc.type}</b><em>${doc.words} 词</em><button class="mini-link" data-action="openDoc" data-id="${doc.id}">打开</button></div>`).join("")}</div>` : `<div class="empty-box"><h3>暂无文档</h3><p>生成文书后会出现在这里</p><button class="primary-btn small" data-route="ps">去写PS</button></div>`}
    </section>
  `;
}

function agenticView() {
  return `
    ${shell("智能文书助手", "全套申请文书，一次搞定。背景分析、Essay搜题、全套文书写作、自动降AI率一步到位")}
    <section class="dash-hero-panel">
      <div>
        <p class="section-kicker">选择学生档案</p>
        <h2>上传新档案或从资料库选择</h2>
        <div class="segmented"><button class="active" data-action="agentUpload">上传新档案</button><button data-action="agentLibrary">从资料库选择</button></div>
        <div id="agentResult" class="checker-result">等待上传或选择学生档案</div>
      </div>
      ${uploadBox("agentFile", "点击或拖拽上传", "支持 PDF, Word, TXT, 图片格式")}
    </section>
  `;
}

function writerView(type) {
  if (type === "ps") return psView();
  const config = {
    pe: ["命题文书", "命题", "输入学校专业指定的命题，中英文皆可", "自定义侧重点", "输入期望在文中着重展现的侧重点", "生成Essay"],
    rl: ["推荐信", "推荐人信息", "把推荐人信息复制粘贴或输入到这里", "定制亮点", "输入希望着重表达的亮点，建议每行一条", "生成推荐信"],
    cv: ["简历", "创意模式", "", "", "", "生成CV"],
    fw: ["自由创作", "写作指引", "请输入写作指引，例如：写一段关于我在小学自学编程的经历", "写作风格", "", "提交生成"]
  }[type];
  const extra = type === "cv"
    ? `<label class="switch-row"><input type="checkbox" />创意模式</label>`
    : type === "fw"
      ? `<label>写作指引<textarea data-field="prompt" placeholder="${config[2]}"></textarea></label><label>写作风格<select data-field="style"><option>Narrative (叙事文)</option><option>Expository (说明文)</option><option>Academic (学术文)</option><option>Creative (创意文)</option></select></label><label>Essay长度 <output id="lenOut">600词</output><input type="range" min="200" max="1200" value="600" data-action="rangeLen" /></label>`
      : `<label>${config[1]}<textarea data-field="prompt" placeholder="${config[2]}"></textarea></label><label>${config[3]}<textarea data-field="focus" placeholder="${config[4]}"></textarea></label><label>${type === "rl" ? "推荐信" : "Essay"}长度 <output id="lenOut">300词</output><input type="range" min="100" max="1000" value="300" data-action="rangeLen" /></label>`;
  return editorShell(config[0], `
    <label>选择学生档案<input type="text" placeholder="选择学生档案" /></label>
    <button class="mini-link" data-action="createClient">还没有创建学生档案？新建一个</button>
    <label>指定目标院校<input type="text" placeholder="例如 University of Manchester" /></label>
    ${extra}
    <button class="primary-btn full" data-action="generateWriter" data-kind="${type}">${config[5]} AI</button>
  `, samples[type]);
}

function psView() {
  return editorShell("写PS", `
    <label>选择学生档案<input type="text" placeholder="选择学生档案" /></label>
    <button class="mini-link" data-action="createClient">还没有创建学生档案？新建一个</button>
    <label>目标院校<input type="text" placeholder="目标院校" /></label>
    <label>申请学位<select><option>Undergraduate</option><option>Graduate</option><option>MBA</option><option>PhD</option></select></label>
    <label>专业<input type="text" value="Undecided" /></label>
    <label>大纲段落<div class="number-pills">${[5,6,7,8,9,10].map(n => `<button data-action="outlineCount">${n}</button>`).join("")}</div></label>
    <label class="switch-row"><input type="checkbox" />启用深度思考</label>
    <label>自定义写作指引 (选填)<textarea placeholder="输入自定义中心思想或亮点等指引，使用第一人称"></textarea></label>
    <button class="primary-btn full" data-action="generateOutline">生成大纲 AI</button>
    <button class="secondary-btn full" data-action="generateWriter" data-kind="ps">生成正文</button>
    <div class="outline-box" id="outlineBox"><b>还没有大纲段落</b><p>生成或手动添加段落开始</p><button class="mini-link" data-action="addOutline">添加段落</button></div>
  `, samples.ps);
}

function editorShell(title, formHtml, sampleText) {
  return `
    <section class="writer-layout">
      <aside class="writer-config"><h2>${title}</h2>${formHtml}</aside>
      <section class="editor-panel">
        <div class="editor-toolbar">
          <b>EduPro 文档编辑</b>
          <div>
            <button class="secondary-btn small" data-action="saveDoc">保存文档</button>
            <button class="secondary-btn small" data-action="exportDoc">导出</button>
            <button class="secondary-btn small" data-action="checkEditor">查AI率</button>
            <button class="secondary-btn small" data-action="humanizeEditor">降AI率</button>
          </div>
        </div>
        <textarea class="doc-editor" id="docEditor" placeholder="生成后的内容会出现在这里">${state.editorText || ""}</textarea>
        <div class="editor-status">单词: <span id="wordCount">0</span> 字数: <span id="charCount">0</span> <span>100%</span></div>
        <template id="sampleText">${sampleText}</template>
      </section>
    </section>
  `;
}

function humanizeView() {
  return `
    ${shell("EduPro降AI率工具", "EduPro独家自主研发的顶尖AI降重模型，特别针对留学申校场景优化。")}
    <section class="humanize-card">
      <div class="dash-card-head">
        <div><h3>输入内容</h3><p class="muted">请输入至少10个单词的内容（仅支持英文）</p></div>
        <button class="mini-link" data-action="guide">降AI率工具使用指南</button>
      </div>
      <textarea id="humanizeInput" class="humanize-input"></textarea>
      <div class="humanize-actions">
        <button class="secondary-btn small" data-action="modelConfig">${icon("settings")}模型配置</button>
        <button class="secondary-btn small" data-action="checkHumanize">${icon("scan-line")}查AI率</button>
        <button class="primary-btn small" data-action="runHumanize">${icon("eraser")}降AI率 AI</button>
        <button class="secondary-btn small warm" data-action="agentHumanize">${icon("sparkles")}Agent模式</button>
      </div>
      <div id="humanizeResult" class="checker-result">等待处理</div>
    </section>
  `;
}

function settingsView() {
  const tab = state.settingsTab;
  const tabs = [["usage", "用量统计"], ["orders", "订单记录"], ["account", "账户信息"], ["sub", "子账户管理"], ["help", "帮助"]];
  return `
    ${shell("账户管理", "管理额度、订单、账户资料和帮助信息")}
    <div class="tabs">${tabs.map(([id, label]) => `<button class="${tab === id ? "active" : ""}" data-settings-tab="${id}">${label}</button>`).join("")}</div>
    ${settingsPanel(tab)}
  `;
}

function settingsPanel(tab) {
  if (tab === "orders") return `<section class="dash-card"><h3>订单记录</h3><div class="empty-box"><p>暂无订单记录</p></div></section>`;
  if (tab === "account") return `<section class="dash-card form-grid"><label>昵称<input value="wx_郝江" /></label><label>邮箱<input value="oydbx2ag10k22x9rmwihzgdvvobi@wx.local" /></label><button class="primary-btn small" data-action="saveAccount">保存账户信息</button><button class="secondary-btn small" data-action="bindWechat">绑定微信号</button></section>`;
  if (tab === "sub") return `<section class="dash-card"><h3>子账户管理</h3><p class="muted">为团队成员创建子账户并分配额度。</p><button class="primary-btn small" data-action="addSubAccount">创建子账户</button></section>`;
  if (tab === "help") return `<section class="dash-card"><h3>帮助</h3><p>遇到问题可以联系客户支持，或查看图文说明。</p><button class="secondary-btn small" data-action="support">客户支持</button></section>`;
  return `
    <section class="dash-stats">
      <article><span>账户余额</span><strong>¥0.00</strong><small><button class="mini-link" data-action="recharge">充值</button> <button class="mini-link" data-settings-tab="orders">明细</button></small></article>
      <article><span>文书生成额度</span><strong>1,000</strong><small>单词 <button class="mini-link" data-action="refreshQuota">刷新</button></small></article>
      <article><span>智能建档额度</span><strong>1</strong><small>次 <button class="mini-link" data-action="refreshQuota">刷新</button></small></article>
    </section>
    <section class="dash-card">
      <div class="dash-card-head"><div><h2>购买流量包 <span class="tag">更划算</span></h2><p class="muted">支付完成后额度直接到账，不限时长永久有效</p></div><button class="icon-btn" data-action="collapsePricing">${icon("chevron-down")}</button></div>
      <div class="pricing-grid">${pricingCards()}</div>
      <button class="mini-link" data-action="pricingDetail">查看定价详情</button>
    </section>
    <section class="dash-grid two-col">
      <article class="dash-card"><h3>使用趋势</h3><div class="tabs small-tabs">${["7天","30天","全部"].map(x=>`<button class="${state.usageRange===x?"active":""}" data-range="${x}">${x}</button>`).join("")}</div><div class="empty-box"><p>暂无使用数据</p></div></article>
      <article class="dash-card"><h3>最近活动</h3><div class="empty-box"><p>暂无记录</p></div></article>
    </section>
  `;
}

function pricingCards() {
  const packs = [["新手体验包 Starter", "¥99", "12,000 单词", "10 次"], ["基础流量包 Plus", "¥488", "80,000 单词", "50 次"], ["专业流量包 Pro", "¥2888", "600,000 单词", "350 次"], ["企业流量包 Enterprise", "¥5888", "1,450,000 单词", "1,000 次"]];
  return packs.map((p, i) => `<article class="price-card ${i === 1 ? "featured" : ""}"><h3>${p[0]} ${i === 1 ? "<span>推荐</span>" : ""}</h3><strong>${p[1]}</strong><button class="${i === 1 ? "primary-btn" : "secondary-btn"} small" data-action="buyPack" data-pack="${p[0]}">购买</button><p>${icon("check")}单词生成 ${p[2]}</p><p>${icon("check")}智能建档 ${p[3]}</p></article>`).join("");
}

function affiliateView() {
  return `
    ${shell("成为合作伙伴", "加入我们，共创价值")}
    <section class="quick-grid">
      <article class="dash-card">${icon("badge-percent")}<h3>高额佣金</h3><p>按客户消费金额比例获得佣金，持续收益。</p></article>
      <article class="dash-card">${icon("repeat-2")}<h3>持续收益</h3><p>客户每次消费都可获得佣金，满足阶梯条件还可提升佣金比例。</p></article>
      <article class="dash-card">${icon("wallet")}<h3>快速提现</h3><p>满 ¥100 即可申请提现，也可随时转化成账户余额。</p></article>
    </section>
    <section class="cta-section compact"><h2>开始赚取佣金</h2><p>通过您的推荐注册的新用户将获得1000词额外奖励。</p><button class="primary-btn" data-action="applyAffiliate">立即申请</button></section>
  `;
}

function uploadBox(id, title, sub) {
  return `<div class="dash-upload" data-drop="${id}"><input id="${id}" type="file" hidden /><i data-lucide="upload-cloud"></i><strong>${title}</strong><span>${sub}</span><button class="secondary-btn small" data-file="${id}">选择文件</button></div>`;
}

function render() {
  state.route = routeFromHash();
  $("#crumbs").textContent = `EduPro › ${labels[state.route] || "总览"}`;
  $$(".dash-nav a").forEach(a => a.classList.toggle("active", a.dataset.route === state.route));
  const view = {
    overview: overviewView,
    studentSummary: studentSummaryView,
    client: clientView,
    docs: docsView,
    agentic: agenticView,
    ps: () => writerView("ps"),
    pe: () => writerView("pe"),
    rl: () => writerView("rl"),
    cv: () => writerView("cv"),
    fw: () => writerView("fw"),
    humanize: humanizeView,
    settings: settingsView,
    affiliate: affiliateView
  }[state.route] || overviewView;
  $("#appView").innerHTML = view();
  bindDynamic();
  lucide.createIcons();
}

function bindDynamic() {
  const editor = $("#docEditor");
  if (editor) {
    updateCounts();
    editor.addEventListener("input", () => {
      state.editorText = editor.value;
      updateCounts();
    });
  }
  $$("[data-file]").forEach(btn => btn.addEventListener("click", () => $(`#${btn.dataset.file}`).click()));
  $$("[data-drop]").forEach(box => {
    ["dragenter", "dragover"].forEach(name => box.addEventListener(name, event => { event.preventDefault(); box.classList.add("dragging"); }));
    ["dragleave", "drop"].forEach(name => box.addEventListener(name, event => { event.preventDefault(); box.classList.remove("dragging"); }));
    box.addEventListener("drop", event => handleFile(event.dataTransfer.files[0], box.dataset.drop));
  });
  const summarySearch = $("#summarySearch");
  if (summarySearch) {
    summarySearch.addEventListener("input", (event) => {
      state.summary.query = event.target.value;
      render();
    });
  }
  const summaryStatus = $("#summaryStatus");
  if (summaryStatus) {
    summaryStatus.addEventListener("change", (event) => {
      state.summary.status = event.target.value;
      render();
    });
  }
}

function updateCounts() {
  const text = $("#docEditor")?.value || "";
  const words = text.trim() ? text.trim().split(/\s+/).length : 0;
  $("#wordCount").textContent = words;
  $("#charCount").textContent = text.length;
}

function buildParsedProfile(name = "Demo Student") {
  const normalized = name.replace(/\.[^.]+$/, "").replace(/[_-]+/g, " ").trim() || "Demo Student";
  const seed = normalized.length;
  const majors = ["Media Studies", "Computer Science", "Finance", "Education", "Business Analytics"];
  const regions = ["英国硕士", "美国本科", "香港硕士", "加拿大硕士"];
  const schools = [
    ["UCL", "University of Manchester", "King's College London"],
    ["NYU", "Boston University", "University of Washington"],
    ["HKU", "CUHK", "HKUST"],
    ["University of Toronto", "UBC", "McGill"]
  ];
  const regionIndex = seed % regions.length;
  return {
    basic: {
      englishName: normalized.split(" ").map(part => part[0]?.toUpperCase() + part.slice(1)).join(" "),
      school: seed % 2 ? "Guangzhou International School" : "Shanghai World Foreign Language Academy",
      gpa: seed % 3 ? "3.72 / 4.00" : "88 / 100",
      language: seed % 2 ? "IELTS 7.0" : "TOEFL 105"
    },
    target: {
      region: regions[regionIndex],
      degree: regions[regionIndex].includes("本科") ? "Undergraduate" : "Graduate",
      major: majors[seed % majors.length],
      schools: schools[regionIndex]
    },
    highlights: [
      "校内研究项目：独立完成资料搜集、访谈和英文报告写作",
      "实习/活动：参与内容策划、数据整理和跨部门沟通",
      "领导力：组织 8 人小组完成阶段性展示并获得导师推荐",
      "个人特质：叙事能力强，适合在 PS 中突出观察力和反思能力"
    ],
    materials: ["Personal Statement", "CV / Resume", "Recommendation Letter", "Prompt Essay"],
    sourceFile: name
  };
}

function parsedPreview(profile) {
  return `
    <div class="parsed-preview">
      <div><b>基础信息</b><span>${profile.basic.englishName} · ${profile.basic.school}</span><span>${profile.basic.gpa} · ${profile.basic.language}</span></div>
      <div><b>申请目标</b><span>${profile.target.degree} · ${profile.target.major}</span><span>${profile.target.schools.join(" / ")}</span></div>
      <div><b>经历亮点</b>${profile.highlights.slice(0, 3).map(item => `<span>${item}</span>`).join("")}</div>
      <div><b>材料清单</b><span>${profile.materials.join("、")}</span></div>
    </div>
  `;
}

function handleFile(file, id) {
  if (!file) return;
  if (id === "summaryUpload") {
    importSummaryWorkbook(file);
    return;
  }
  if (id === "agentFile") {
    $("#agentResult").innerHTML = `<strong>${file.name}</strong><span>已识别学生背景，正在准备全套文书。</span>`;
    state.clients.unshift({ name: file.name.replace(/\.[^.]+$/, ""), status: "服务中", source: "智能建档", profile: buildParsedProfile(file.name) });
    showToast("档案已识别");
    render();
    return;
  }
  if (id === "clientFile") {
    const profile = buildParsedProfile(file.name);
    state.pendingClientFile = { fileName: file.name, profile };
    const result = $("#clientParseResult");
    if (result) {
      result.innerHTML = `<div class="parse-state done">${icon("check-circle")}解析完成：已自动归类学生信息</div>${parsedPreview(profile)}`;
      lucide.createIcons();
    }
    const nameInput = $("#clientName");
    if (nameInput && !nameInput.value.trim()) nameInput.value = profile.basic.englishName;
    showToast("学生信息已解析");
    return;
  }
  state.clients.unshift({ name: file.name.replace(/\.[^.]+$/, ""), status: "服务中", source: "智能建档", profile: buildParsedProfile(file.name) });
  showToast("档案已识别");
  render();
}

async function importSummaryWorkbook(file) {
  if (!window.XLSX) {
    showToast("Excel 解析库未加载，请检查网络后刷新页面");
    return;
  }
  const buffer = await file.arrayBuffer();
  const workbook = XLSX.read(buffer, { type: "array", cellDates: true });
  const appSheetName = workbook.SheetNames.find((name) => name.includes("申请")) || workbook.SheetNames[0];
  const followSheetName = workbook.SheetNames.find((name) => name.includes("后续")) || workbook.SheetNames[1];
  const appRowsRaw = XLSX.utils.sheet_to_json(workbook.Sheets[appSheetName], { header: 1, defval: "" });
  const followRowsRaw = followSheetName ? XLSX.utils.sheet_to_json(workbook.Sheets[followSheetName], { defval: "" }) : [];

  const appRows = appRowsRaw.slice(3).map((row) => {
    const record = makeRow(applicationColumns);
    applicationColumns.forEach((column, index) => {
      record[column] = row[index] ?? "";
    });
    return recalculateApplicationRow(record);
  }).filter((row) => Object.values(row).some((value) => value !== "" && value !== null));

  const followRows = followRowsRaw.map((source) => {
    const record = makeRow(followupColumns);
    followupColumns.forEach((column) => {
      record[column] = source[column] ?? "";
    });
    return record;
  }).filter((row) => Object.values(row).some((value) => value !== "" && value !== null));

  state.summary.rows = appRows.length ? appRows : defaultSummaryRows();
  state.summary.followups = followRows.length ? followRows : defaultFollowupRows();
  state.summary.tab = "applications";
  state.summary.query = "";
  state.summary.status = "all";
  render();
  showToast(`已导入 ${state.summary.rows.length} 条申请记录，${state.summary.followups.length} 条后续安排`);
}

function downloadSummaryWorkbook() {
  if (!window.XLSX) {
    showToast("Excel 导出库未加载，请检查网络后刷新页面");
    return;
  }
  recalculateSummary();
  const wb = XLSX.utils.book_new();
  const appRows = state.summary.rows.map((row) => {
    const out = {};
    applicationColumns.forEach((column) => out[column] = row[column] ?? "");
    return out;
  });
  const followRows = state.summary.followups.map((row) => {
    const out = {};
    followupColumns.forEach((column) => out[column] = row[column] ?? "");
    return out;
  });
  const appSheet = XLSX.utils.json_to_sheet(appRows, { header: applicationColumns });
  const followSheet = XLSX.utils.json_to_sheet(followRows, { header: followupColumns });
  XLSX.utils.book_append_sheet(wb, appSheet, "2026入学学生申请");
  XLSX.utils.book_append_sheet(wb, followSheet, "学生后续安排");
  XLSX.writeFile(wb, "学生汇总.xlsx");
  showToast("学生汇总 Excel 已下载");
}

function recalculateSummary() {
  state.summary.rows.forEach(recalculateApplicationRow);
}

function modal(html) {
  const root = $("#modalRoot");
  root.innerHTML = `<div class="modal-card dash-modal" role="dialog" aria-modal="true">${html}<button class="icon-btn close-modal" data-action="closeModal" aria-label="关闭">${icon("x")}</button></div>`;
  root.classList.add("open");
  root.setAttribute("aria-hidden", "false");
  lucide.createIcons();
  bindDynamic();
}

function closeModal() {
  $("#modalRoot").classList.remove("open");
  $("#modalRoot").setAttribute("aria-hidden", "true");
  $("#modalRoot").innerHTML = "";
}

function createClientModal() {
  modal(`
    <h2>创建客户</h2>
    <label>昵称<input id="clientName" placeholder="输入客户昵称，仅自己可见" /></label>
    <label class="switch-row"><input id="smartArchive" type="checkbox" checked />智能建档?</label>
    <h3>AI智能建档</h3>
    <p class="muted">上传客户信息收集表格，自动识别内容完成学生档案建立，免手输操作</p>
    ${uploadBox("clientFile", "拖拽文档到这里", "支持 pdf, docx, doc, txt, png, jpg, jpeg, gif, webp")}
    <div id="clientParseResult" class="client-parse-result">
      <div class="parse-state">${icon("scan-line")}上传文件后自动解析并归类学生信息</div>
    </div>
    <button class="primary-btn full" data-action="confirmClient">确认创建</button>
    <button class="secondary-btn full" data-action="closeModal">取消</button>
  `);
}

function searchModal() {
  const items = [["overview","总览"],["client","学生档案"],["docs","我的作品"],["agentic","文书Agent"],["ps","写PS"],["pe","命题文书"],["rl","写推荐信"],["cv","写CV"],["fw","自由创作"],["humanize","降AI率"],["settings","账户管理"],["affiliate","推广合作"]];
  modal(`
    <h3>EduPro搜索</h3>
    <input id="searchInput" class="search-input" placeholder="搜索文档、客户..." autofocus />
    <div class="command-list">${items.map(([route, text]) => `<button data-route="${route}" data-search-item>${text}</button>`).join("")}</div>
  `);
  $("#searchInput").addEventListener("input", event => {
    const q = event.target.value.trim();
    $$("[data-search-item]").forEach(btn => btn.hidden = q && !btn.textContent.includes(q));
  });
}

function avatarMenu() {
  const pop = $("#popoverRoot");
  pop.innerHTML = `<div class="avatar-menu"><b>wx_郝江</b><p>oydbx2ag10k22x9rmwihzgdvvobi@wx.local</p><button data-route="settings">${icon("settings")}账户设置</button><button data-action="support">${icon("circle-help")}客户支持</button><button data-action="logout">${icon("log-out")}退出登录</button></div>`;
  pop.classList.toggle("open");
  lucide.createIcons();
}

function modelConfig() {
  modal(`
    <div class="dash-card-head"><h2>模型配置</h2><button class="mini-link" data-action="defaultModel">使用默认参数</button></div>
    <label>模型版本<select id="modelVersion"><option>v7.0.2</option><option>v6.0.0</option><option>v5.0.4</option><option>v5.0.0</option><option>v4.0.0</option></select></label>
    <label>文体类型<select id="modelGenre"><option>个人陈述 (Personal Statement)</option><option>学术 (Academic)</option><option>论文 (Research Paper)</option><option>创意 (Creative)</option></select></label>
    <label>写作水平<select id="modelLevel"><option>高级 (Advanced)</option><option>精通 (Mastery)</option></select></label>
    <label class="switch-row"><input id="boostedMode" type="checkbox" ${state.humanize.boosted ? "checked" : ""} />加强模式 <small>BOOSTED MODE</small></label>
    <button class="primary-btn full" data-action="saveModel">保存配置</button>
    <button class="mini-link" data-action="guide">降AI率工具使用指南</button>
  `);
}

function paymentModal(pack = "基础流量包 Plus") {
  modal(`<h2>确认购买</h2><p class="muted">${pack}。这是本地复刻演示，不会发起真实支付。</p><div class="qr-demo">${icon("qr-code")}<span>微信 / 支付宝扫码支付</span></div><button class="primary-btn full" data-action="mockPaid">我已完成支付</button>`);
}

async function callAI(task, input, options = {}) {
  try {
    showToast("ChatGPT 正在处理...");
    const response = await fetch("/api/ai", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ task, input, options })
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "AI request failed");
    return data.text;
  } catch (error) {
    const message = error.message === "Missing OPENAI_API_KEY"
      ? "请先在本地服务中配置 OPENAI_API_KEY"
      : `AI 调用失败：${error.message}`;
    showToast(message);
    throw error;
  }
}

function collectWriterInput(kind) {
  const config = $(".writer-config");
  if (!config) return `文书类型：${kind}`;
  const fields = $$("textarea, input, select", config)
    .map((field) => {
      const label = field.closest("label")?.innerText.split("\n")[0] || field.placeholder || field.type;
      const value = field.type === "checkbox" ? field.checked : field.value;
      return `${label}: ${value}`;
    })
    .join("\n");
  return `${fields}\n\n文书类型：${kind}`;
}

async function generateDoc(kind) {
  const title = { ps: "Personal Statement", pe: "Prompt Essay", rl: "Recommendation Letter", cv: "CV Resume", fw: "Free Writing" }[kind] || "Document";
  let text;
  try {
    text = await callAI("writer", collectWriterInput(kind), { kind });
  } catch {
    text = samples[kind] || samples.fw;
  }
  state.editorText = text;
  state.docs.unshift({ id: Date.now(), title, type: kind.toUpperCase(), words: text.split(/\s+/).length });
  render();
  showToast(`${title} 已生成`);
}

async function generateOutlineWithAI() {
  const target = $("#outlineBox");
  try {
    const text = await callAI("outline", collectWriterInput("ps"));
    target.innerHTML = `<b>1 编辑大纲</b>${text.split("\n").filter(Boolean).map((line) => `<p>${line}</p>`).join("")}`;
    showToast("大纲已由 ChatGPT 生成");
  } catch {
    target.innerHTML = `<b>1 编辑大纲</b><p>Opening: connect a personal story to the target major.</p><p>Body: describe project experience and academic preparation.</p><p>Closing: explain school fit and future goals.</p>`;
  }
}

function estimateLocalAIRate(text) {
  const polishWords = ["passion", "meaningful", "deeply", "vibrant", "journey", "challenge", "recognized", "connection", "demonstrates", "significant"];
  const hits = polishWords.reduce((count, word) => count + (text.toLowerCase().includes(word) ? 1 : 0), 0);
  const lengthFactor = Math.min(text.length / 900, 1);
  return Math.min(96, Math.round(28 + hits * 7 + lengthFactor * 32));
}

function localHumanizeText(text) {
  const replacements = [
    [/\bMy passion for\b/g, "I first became drawn to"],
    [/\bmy passion for\b/g, "my interest in"],
    [/\bemerged from\b/g, "started in"],
    [/\bmore deeply\b/g, "with more patience"],
    [/\bmeaningful\b/g, "important"],
    [/\bdemonstrates\b/g, "shows"],
    [/\bsignificant\b/g, "clear"],
    [/\butilize\b/g, "use"],
    [/\bfurthermore\b/gi, "also"],
    [/\bmoreover\b/gi, "also"],
    [/\bin conclusion\b/gi, "Looking back"],
    [/\bI believe that\b/g, "I think"],
    [/\bIt is important to note that\b/g, "I noticed that"],
    [/\bThis experience taught me that\b/g, "From this, I learned"],
    [/\bThe excitement grew when\b/g, "That interest became more concrete when"],
    [/\brepresented something far more meaningful\b/g, "meant more to me than a prize"],
    [/\ba genuine connection between people\b/g, "a moment where people understood the same feeling"]
  ];
  let rewritten = replacements.reduce((value, [pattern, replacement]) => value.replace(pattern, replacement), text);

  if (rewritten === text) {
    rewritten = text
      .split(/(?<=[.!?])\s+/)
      .map((sentence, index) => {
        if (!sentence.trim()) return sentence;
        if (index === 0) return sentence.replace(/^([A-Z])/, "In practice, $1").replace("In practice, I ", "In practice, I ");
        if (index % 2 === 1) return sentence.replace(/^I /, "I also ").replace(/^The /, "That ");
        return sentence.replace(/^This /, "That ").replace(/^It /, "For me, it ");
      })
      .join(" ");
  }

  return rewritten;
}

function checkAIText(source = "humanize") {
  const area = source === "editor" ? $("#docEditor") : $("#humanizeInput");
  if (!area || !area.value.trim()) return showToast("请先输入内容");
  const rate = estimateLocalAIRate(area.value);
  const title = rate > 65 ? "风险偏高" : rate > 28 ? "需要优化" : "状态安全";
  const advice = rate > 65
    ? "文本表达较规整，抽象词和总结性句式偏多。建议加入更具体的经历细节、动作和个人判断。"
    : rate > 28
      ? "整体可用，但部分句子仍像通用 AI 输出。建议降低模板化转折，保留个人语气。"
      : "文本已经比较自然，可以进入人工校对和格式整理。";
  const html = `<strong>AI率 ${rate}% · ${title}</strong><span>${advice}</span>`;
  if (source === "editor") {
    modal(`<h2>查AI率结果</h2><div class="checker-result">${html}</div><button class="primary-btn full" data-action="closeModal">关闭</button>`);
  }
  if ($("#humanizeResult")) $("#humanizeResult").innerHTML = html;
  showToast("查AI率完成");
}

function runHumanize(source = "humanize") {
  const area = source === "editor" ? $("#docEditor") : $("#humanizeInput");
  if (!area || !area.value.trim()) return showToast("请先输入内容");
  const rate = estimateLocalAIRate(area.value);
  const improved = Math.max(3, Math.round(rate * 0.18));
  area.value = localHumanizeText(area.value);
  const result = source === "editor" ? `AI率 ${rate}% → ${improved}%` : `<strong>AI率 ${rate}% → ${improved}%</strong><span>已弱化模板感，并加入更像个人叙述的节奏。</span>`;
  if (source === "editor") updateCounts();
  if ($("#humanizeResult")) $("#humanizeResult").innerHTML = result;
  showToast("降AI率完成");
}

function runAgentHumanize() {
  const area = $("#humanizeInput");
  if (!area || !area.value.trim()) return showToast("请先输入内容");
  $("#humanizeResult").innerHTML = "<strong>Agent模式运行中</strong><span>正在自动检测文体并迭代至目标 AI 率。</span>";
  window.setTimeout(() => runHumanize("humanize"), 450);
}

function handleAction(target) {
  const action = target.dataset.action;
  const route = target.dataset.route;
  const settingsTab = target.dataset.settingsTab;
  if (route) { closeModal(); $("#popoverRoot").classList.remove("open"); return setRoute(route); }
  if (settingsTab) { state.settingsTab = settingsTab; return render(); }
  if (target.dataset.range) { state.usageRange = target.dataset.range; return render(); }
  if (!action) return;
  const map = {
    createClient: createClientModal,
    closeModal,
    uploadSummary: () => $("#summaryUpload")?.click(),
    downloadSummary: () => downloadSummaryWorkbook(),
    setSummaryTab: () => { state.summary.tab = target.dataset.tab || "applications"; render(); },
    addSummaryRow: () => {
      if (state.summary.tab === "applications") {
        state.summary.rows.push(recalculateApplicationRow(makeRow(applicationColumns, { "序号": state.summary.rows.length + 1 })));
      } else {
        state.summary.followups.push(makeRow(followupColumns));
      }
      render();
      showToast("已新增一行");
    },
    recalculateSummary: () => {
      recalculateSummary();
      render();
      showToast("公式已重算");
    },
    video: () => modal(`<h2>视频演示</h2><div class="video-demo">${icon("play-circle")}EduPro 核心功能演示</div><button class="primary-btn full" data-action="closeModal">知道了</button>`),
    guide: () => modal(`<h2>快速开始</h2><ol><li>创建学生档案</li><li>选择写作工具</li><li>生成、保存、导出文档</li><li>使用降AI率工具优化交付</li></ol><button class="primary-btn full" data-action="closeModal">开始使用</button>`),
    settings: () => setRoute("settings"),
    usage: () => { state.settingsTab = "usage"; setRoute("settings"); },
    modelConfig,
    recharge: () => paymentModal("余额充值"),
    buyPack: () => paymentModal(target.dataset.pack),
    confirmClient: () => {
      const name = $("#clientName")?.value.trim() || "新客户";
      const parsed = state.pendingClientFile;
      const profile = parsed?.profile || buildParsedProfile(name);
      profile.basic.englishName = name;
      state.clients.unshift({ name, status: "服务中", source: parsed ? `智能建档 · ${parsed.fileName}` : ($("#smartArchive")?.checked ? "智能建档" : "手动创建"), profile });
      state.pendingClientFile = null;
      closeModal();
      setRoute("client");
      showToast(parsed ? "客户已创建，学生信息已归类" : "客户已创建");
    },
    generateWriter: () => generateDoc(target.dataset.kind),
    generateOutline: () => generateOutlineWithAI(),
    addOutline: () => { $("#outlineBox").insertAdjacentHTML("beforeend", "<p>新段落：补充一个具体经历与反思。</p>"); },
    saveDoc: () => showToast("文档已保存"),
    exportDoc: () => showToast("已导出 Word 文档"),
    checkEditor: () => checkAIText("editor"),
    humanizeEditor: () => runHumanize("editor"),
    checkHumanize: () => checkAIText("humanize"),
    runHumanize: () => runHumanize("humanize"),
    agentHumanize: () => runAgentHumanize(),
    saveModel: () => { state.humanize.model = $("#modelVersion").value; state.humanize.genre = $("#modelGenre").value; state.humanize.level = $("#modelLevel").value; state.humanize.boosted = $("#boostedMode").checked; closeModal(); showToast("模型配置已保存"); },
    defaultModel: () => { state.humanize = { model: "v7.0.2", genre: "个人陈述 (Personal Statement)", level: "高级 (Advanced)", boosted: false }; closeModal(); showToast("已恢复默认参数"); },
    refreshQuota: () => showToast("额度已刷新"),
    pricingDetail: () => modal("<h2>定价详情</h2><p>查AI率按千词折扣消耗，流量包永久有效。此处为本地演示。</p><button class='primary-btn full' data-action='closeModal'>关闭</button>"),
    support: () => showToast("客户支持入口已打开"),
    applyAffiliate: () => modal("<h2>申请合作伙伴</h2><label>联系方式<input placeholder='微信或邮箱' /></label><button class='primary-btn full' data-action='closeModal'>提交申请</button>"),
    mockPaid: () => { closeModal(); showToast("支付成功，额度已到账"); },
    logout: () => { $("#popoverRoot").classList.remove("open"); showToast("已退出登录"); },
    saveAccount: () => showToast("账户信息已保存"),
    bindWechat: () => showToast("微信绑定二维码已生成"),
    addSubAccount: () => modal("<h2>创建子账户</h2><label>邮箱<input placeholder='member@example.com' /></label><label>分配额度<input value='1000' /></label><button class='primary-btn full' data-action='closeModal'>创建</button>"),
    setClientFilter: () => { state.clientFilter = target.dataset.filter || "active"; render(); },
    archiveClient: () => {
      const client = state.clients.find((item) => item.name === target.dataset.name);
      if (client) client.status = "已归档";
      state.clientFilter = "archived";
      render();
      showToast(`${target.dataset.name} 已移动到已归档`);
    },
    restoreClient: () => {
      const client = state.clients.find((item) => item.name === target.dataset.name);
      if (client) client.status = "服务中";
      state.clientFilter = "active";
      render();
      showToast(`${target.dataset.name} 已恢复服务中`);
    },
    agentLibrary: () => $("#agentResult").innerHTML = "<strong>资料库为空</strong><span>请先创建学生档案。</span>",
    agentUpload: () => $("#agentResult").textContent = "请上传新档案"
  };
  map[action]?.();
}

document.addEventListener("click", event => {
  const target = event.target.closest("[data-action], [data-route], [data-settings-tab], [data-range]");
  const fileTarget = event.target.closest("[data-file]");
  if (fileTarget) {
    $(`#${fileTarget.dataset.file}`)?.click();
    return;
  }
  if (target) handleAction(target);
});

document.addEventListener("change", event => {
  if (event.target.matches("input[type=file]")) {
    handleFile(event.target.files[0], event.target.id);
  }
});

document.addEventListener("input", event => {
  const input = event.target.closest("[data-summary-table]");
  if (!input) return;
  const table = input.dataset.summaryTable;
  const rowIndex = Number(input.dataset.row);
  const column = input.dataset.col;
  const rows = table === "applications" ? getFilteredSummaryRows() : state.summary.followups;
  const row = rows[rowIndex];
  if (!row || column === "剩余天数") return;
  row[column] = input.value;
  if (table === "applications") recalculateApplicationRow(row);
});

$("#dashMenu").addEventListener("click", () => $("#dashSidebar").classList.toggle("open"));
$("#collapseSidebar").addEventListener("click", () => $("#dashSidebar").classList.toggle("collapsed"));
$("#openSearch").addEventListener("click", searchModal);
$("#avatarBtn").addEventListener("click", avatarMenu);
$("#themeToggleDash").addEventListener("click", () => document.body.classList.toggle("dark"));
$("#modalRoot").addEventListener("click", event => { if (event.target.id === "modalRoot") closeModal(); });
document.addEventListener("keydown", event => {
  if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "k") { event.preventDefault(); searchModal(); }
  if (event.key === "Escape") { closeModal(); $("#popoverRoot").classList.remove("open"); }
});
window.addEventListener("hashchange", render);

render();
