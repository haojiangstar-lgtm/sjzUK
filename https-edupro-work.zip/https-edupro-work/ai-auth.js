(function () {
  const required = document.body.dataset.requireChatgptLogin === "true";
  if (!required || localStorage.getItem("edupro_chatgpt_connected") === "yes") return;

  const overlay = document.createElement("div");
  overlay.className = "chatgpt-gate";
  overlay.innerHTML = `
    <div class="chatgpt-gate-card">
      <div class="gate-logo">ChatGPT</div>
      <h1>请先登录 ChatGPT</h1>
      <p>登录完成后返回本页，点击“我已登录”，即可进入 EduPro。所有 AI 写作、查 AI 率和降 AI 率操作将通过后端 OpenAI API 调用 ChatGPT 模型完成。</p>
      <div class="gate-actions">
        <a class="primary-btn" href="https://chatgpt.com/auth/login" target="_blank" rel="noreferrer">前往 ChatGPT 登录</a>
        <button class="secondary-btn" id="confirmChatGPTLogin">我已登录，进入 EduPro</button>
      </div>
      <small id="gateStatus">正在检查本地 AI 服务...</small>
    </div>
  `;
  document.body.appendChild(overlay);

  fetch("/api/session")
    .then((res) => res.json())
    .then((data) => {
      const status = document.getElementById("gateStatus");
      if (!status) return;
      status.textContent = data.hasApiKey
        ? `AI 服务已就绪：${data.model}`
        : "AI 服务尚未配置 OPENAI_API_KEY，进入后 AI 按钮会提示配置。";
    })
    .catch(() => {
      const status = document.getElementById("gateStatus");
      if (status) status.textContent = "当前是静态服务模式，需用 server.js 启动后端才能调用 AI。";
    });

  document.getElementById("confirmChatGPTLogin").addEventListener("click", () => {
    localStorage.setItem("edupro_chatgpt_connected", "yes");
    overlay.remove();
  });
})();
