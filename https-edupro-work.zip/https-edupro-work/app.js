const sample = `My passion for storytelling emerged from the vibrant world of art and led me toward understanding reality more deeply. During my high school years in Guangzhou, I began performing on stage with our drama group, creating and portraying characters in situations that ranged from completely foreign to painfully personal.

The excitement grew when I took on the challenge of producing a short film about a young artist's path, handling the writing, directing, filming, and editing myself. Receiving Best Student Short at our school festival felt wonderful, but I recognized it represented something far more meaningful: a genuine connection between people.`;

const $ = (selector) => document.querySelector(selector);

const sourceText = $("#sourceText");
const scoreValue = $("#scoreValue");
const scoreArc = $("#scoreArc");
const resultTitle = $("#resultTitle");
const resultText = $("#resultText");
const outputText = $("#outputText");
const toast = $("#toast");

function showToast(text) {
  toast.textContent = text;
  toast.classList.add("show");
  window.setTimeout(() => toast.classList.remove("show"), 1800);
}

function estimateRate(text) {
  if (!text.trim()) return 0;
  const polishWords = ["passion", "meaningful", "deeply", "vibrant", "journey", "challenge", "recognized", "connection"];
  const hits = polishWords.reduce((count, word) => count + (text.toLowerCase().includes(word) ? 1 : 0), 0);
  const lengthFactor = Math.min(text.length / 900, 1);
  return Math.min(96, Math.round(36 + hits * 7 + lengthFactor * 26));
}

function setScore(rate) {
  const normalized = Math.max(0, Math.min(rate, 100));
  scoreValue.textContent = `${normalized}%`;
  scoreArc.style.strokeDashoffset = 314 - (314 * normalized) / 100;
  scoreArc.style.stroke = normalized > 65 ? "#ff6375" : normalized > 28 ? "#ffc947" : "#20c997";
}

function detect() {
  const text = sourceText.value.trim();
  if (!text) {
    showToast("先粘贴一段文书内容");
    return;
  }
  const rate = estimateRate(text);
  setScore(rate);
  resultTitle.textContent = rate > 65 ? "风险偏高" : rate > 28 ? "需要优化" : "状态安全";
  resultText.textContent =
    rate > 65
      ? "文本表达较规整，抽象词和总结性句式偏多。建议加入更具体的经历细节、动作和个人判断。"
      : rate > 28
        ? "整体可用，但部分句子仍像通用 AI 输出。建议降低模板化转折，保留个人语气。"
        : "文本已经比较自然，可以进入人工校对和格式整理。";
}

function humanize() {
  const text = sourceText.value.trim();
  if (!text) {
    showToast("先粘贴一段文书内容");
    return;
  }
  const rewritten = text
    .replaceAll("My passion for", "I first became drawn to")
    .replaceAll("emerged from", "started in")
    .replaceAll("more deeply", "with more patience")
    .replaceAll("The excitement grew when", "That interest became more concrete when")
    .replaceAll("represented something far more meaningful", "meant more to me than a prize")
    .replaceAll("a genuine connection between people", "a moment where people understood the same feeling");

  outputText.textContent = rewritten;
  setScore(Math.max(3, Math.round(estimateRate(text) * 0.18)));
  resultTitle.textContent = "已完成自然化改写";
  resultText.textContent = "已弱化模板感，加入更像个人叙述的节奏。真实项目中这里可以接入你的 AI 改写接口。";
  showToast("降 AI 率完成");
}

$("#sampleText").addEventListener("click", () => {
  sourceText.value = sample;
  detect();
});

$("#detectBtn").addEventListener("click", detect);
$("#humanizeBtn").addEventListener("click", humanize);

$("#copyOutput").addEventListener("click", async () => {
  const text = outputText.textContent.trim();
  if (!text || text === "降 AI 后的文本会显示在这里。") {
    showToast("暂无可复制内容");
    return;
  }
  await navigator.clipboard.writeText(text);
  showToast("已复制改写结果");
});

const modal = $("#loginModal");
function openLogin() {
  modal.classList.add("open");
  modal.setAttribute("aria-hidden", "false");
}
function closeLogin() {
  modal.classList.remove("open");
  modal.setAttribute("aria-hidden", "true");
}

$("#openLogin").addEventListener("click", openLogin);
$("#openLogin2").addEventListener("click", openLogin);
$("#closeLogin").addEventListener("click", closeLogin);
$("#fakeLogin").addEventListener("click", () => {
  closeLogin();
  showToast("登录成功，已领取体验额度");
  window.setTimeout(() => {
    window.location.href = "dashboard.html";
  }, 500);
});
modal.addEventListener("click", (event) => {
  if (event.target === modal) closeLogin();
});

$("#playDemo").addEventListener("click", () => showToast("演示视频入口已就绪"));

$("#themeToggle").addEventListener("click", () => {
  document.body.classList.toggle("dark");
  const icon = document.body.classList.contains("dark") ? "sun" : "moon";
  $("#themeToggle").innerHTML = `<i data-lucide="${icon}"></i>`;
  lucide.createIcons();
});

$("#openMenu").addEventListener("click", () => {
  $(".main-nav").classList.toggle("open");
});

document.querySelectorAll(".main-nav a").forEach((link) => {
  link.addEventListener("click", () => $(".main-nav").classList.remove("open"));
});

const dropZone = $("#dropZone");
const fileInput = $("#fileInput");
const fileName = $("#fileName");

function handleFile(file) {
  if (!file) return;
  fileName.textContent = file.name;
  dropZone.classList.add("has-file");
  showToast("已识别学生档案");
}

$("#chooseFile").addEventListener("click", () => fileInput.click());
fileInput.addEventListener("change", (event) => handleFile(event.target.files[0]));

["dragenter", "dragover"].forEach((name) => {
  dropZone.addEventListener(name, (event) => {
    event.preventDefault();
    dropZone.classList.add("dragging");
  });
});

["dragleave", "drop"].forEach((name) => {
  dropZone.addEventListener(name, (event) => {
    event.preventDefault();
    dropZone.classList.remove("dragging");
  });
});

dropZone.addEventListener("drop", (event) => handleFile(event.dataTransfer.files[0]));

window.addEventListener("keydown", (event) => {
  if (event.key === "Escape") closeLogin();
});

lucide.createIcons();
