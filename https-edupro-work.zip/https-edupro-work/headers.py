﻿from openpyxl import load_workbook
from openpyxl.utils import get_column_letter
p=r'C:\Users\nov\Desktop\申请进度大表（沟通小结自动生成）.xlsx'
wb=load_workbook(p, data_only=False)
ws=wb['2026入学学生申请']
for c in range(1, 38):
    h1=ws.cell(1,c).value
    h2=ws.cell(2,c).value
    h3=ws.cell(3,c).value
    header=' / '.join(str(x) for x in [h1,h2,h3] if x is not None)
    print(c, get_column_letter(c), header)
print('\nSample non-empty rows A:AK')
for r in range(4, 35):
    vals=[ws.cell(r,c).value for c in range(1,38)]
    if any(v is not None and not (isinstance(v,str) and v.startswith('=')) for v in vals):
        print(r, vals)
