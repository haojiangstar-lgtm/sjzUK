const http = require("http");
const fs = require("fs/promises");
const path = require("path");

const root = __dirname;
const port = Number(process.env.PORT || 5173);
const model = process.env.OPENAI_MODEL || "gpt-5.5";

const types = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".svg": "image/svg+xml"
};

function sendJson(res, status, data) {
  res.writeHead(status, { "Content-Type": "application/json; charset=utf-8" });
  res.end(JSON.stringify(data));
}

async function readBody(req) {
  const chunks = [];
  for await (const chunk of req) chunks.push(chunk);
  return Buffer.concat(chunks).toString("utf8");
}

function buildPrompt(task, input, options = {}) {
  const base = [
    "你是 EduPro 内置的 ChatGPT 留学文书助手。",
    "只输出用户可直接使用的结果，不要解释你是 AI。",
    "写作内容以英文为主，界面提示可以用中文。",
    "保持留学申请语境，避免夸张、空泛和模板化。"
  ].join("\n");

  const prompts = {
    outline: `为 Personal Statement 生成 5 段式英文大纲。背景/要求：${input || "未提供"}`,
    writer: `生成一篇 ${options.kind || "application"} 文书。要求：${input || "根据默认申请背景写作"}`,
    humanize: `降低下列英文文本的 AI 痕迹，保留原意和结构，输出改写后的英文文本：\n\n${input}`,
    check: `评估下列英文文本的 AI 检测风险，用中文输出：AI率估计、风险段落、优化建议。\n\n${input}`,
    agent: `根据学生档案信息生成全套申请文书计划，包括 PS、CV、推荐信、命题 Essay 和降 AI 步骤：\n\n${input}`
  };

  return [
    { role: "system", content: base },
    { role: "user", content: prompts[task] || String(input || "") }
  ];
}

async function callOpenAI(payload) {
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) {
    const error = new Error("Missing OPENAI_API_KEY");
    error.status = 503;
    throw error;
  }

  const response = await fetch("https://api.openai.com/v1/responses", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${apiKey}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      model,
      input: buildPrompt(payload.task, payload.input, payload.options)
    })
  });

  const data = await response.json();
  if (!response.ok) {
    const error = new Error(data.error?.message || "OpenAI request failed");
    error.status = response.status;
    throw error;
  }

  const text =
    data.output_text ||
    data.output?.flatMap((item) => item.content || [])
      .map((part) => part.text || "")
      .join("")
      .trim();

  return { text: text || "", model };
}

async function handleApi(req, res) {
  if (req.url === "/api/session") {
    return sendJson(res, 200, {
      chatgptLoginUrl: "https://chatgpt.com/auth/login",
      hasApiKey: Boolean(process.env.OPENAI_API_KEY),
      model
    });
  }

  if (req.url === "/api/ai" && req.method === "POST") {
    try {
      const payload = JSON.parse(await readBody(req) || "{}");
      const result = await callOpenAI(payload);
      return sendJson(res, 200, result);
    } catch (error) {
      return sendJson(res, error.status || 500, {
        error: error.message || "AI request failed"
      });
    }
  }

  return false;
}

async function serveStatic(req, res) {
  const urlPath = decodeURIComponent(req.url.split("?")[0]);
  const filePath = path.resolve(root, urlPath === "/" ? "index.html" : `.${urlPath}`);
  if (!filePath.startsWith(root)) {
    res.writeHead(403);
    res.end("Forbidden");
    return;
  }
  try {
    const data = await fs.readFile(filePath);
    res.writeHead(200, { "Content-Type": types[path.extname(filePath)] || "application/octet-stream" });
    res.end(data);
  } catch {
    res.writeHead(404);
    res.end("Not found");
  }
}

http.createServer(async (req, res) => {
  if (req.url.startsWith("/api/")) {
    const handled = await handleApi(req, res);
    if (handled !== false) return;
  }
  await serveStatic(req, res);
}).listen(port, () => {
  console.log(`EduPro AI server running at http://localhost:${port}`);
  console.log(process.env.OPENAI_API_KEY ? `OpenAI model: ${model}` : "OPENAI_API_KEY is not set; AI calls will show setup guidance.");
});
