﻿from openpyxl import load_workbook
p=r'C:\Users\nov\Desktop\申请进度大表（沟通小结自动生成）.xlsx'
wb=load_workbook(p, data_only=False)
for ws in wb.worksheets:
    print('\nSHEET', ws.title, ws.max_row, ws.max_column)
    for r in range(1, min(ws.max_row, 4)+1):
        vals=[ws.cell(r,c).value for c in range(1, ws.max_column+1)]
        print('ROW', r, vals)
    print('merged', list(ws.merged_cells.ranges)[:20])
    formulas=[]
    for row in ws.iter_rows():
        for cell in row:
            if isinstance(cell.value,str) and cell.value.startswith('='):
                formulas.append((cell.coordinate, cell.value))
    print('formula count', len(formulas), formulas[:30])
